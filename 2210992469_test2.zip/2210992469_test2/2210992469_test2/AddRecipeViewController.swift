//
//  AddRecipeViewController.swift
//  2210992469_test2
//
//  Created by student-2 on 23/11/24.
//

import UIKit

import UIKit

class AddRecipeViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var categoryTextField: UITextField!
    @IBOutlet weak var ingredientsTextView: UITextView!
    @IBOutlet weak var instructionsTextView: UITextView!
    @IBOutlet weak var caloriesTextField: UITextField!
    @IBOutlet weak var prepTimeTextField: UITextField!
    @IBOutlet weak var imageView: UIImageView!

    var selectedImage: UIImage?

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func saveRecipeTapped(_ sender: Any) {
       
            return
        }

        let newRecipe = Recipe(name: "Pancakes", ingredients: "Flour, eggs, milk", instructions: "Mix and cook", category: "Breakfast", calories: 300, prepTime: 15, image: nil)
  
    }


   



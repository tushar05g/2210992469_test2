//
//  Meal.swift
//  2210992469_test2
//
//  Created by student-2 on 23/11/24.
//

import UIKit

struct MealPlan {
    var mealType: String
    var day: String 
    var recipe: Recipe
}

    


//
//  Food.swift
//  2210992469_test2
//
//  Created by student-2 on 23/11/24.
//

import UIKit

struct Recipe {
    var name: String
    var ingredients: String
    var instructions: String
    var category: String
    var calories: Int
    var prepTime: Int
    var image: UIImage?
}


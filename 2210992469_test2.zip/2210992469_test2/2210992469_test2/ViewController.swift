//
//  ViewController.swift
//  2210992469_test2
//
//  Created by student-2 on 23/11/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var mealPlans = [MealPlan]()
    
    @IBOutlet weak var mealPlanTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mealPlanTableView.dataSource = self
        mealPlanTableView.delegate = self
        
        let sampleRecipe = Recipe(name: "Pancakes", ingredients: "Flour, eggs, milk", instructions: "Mix and cook", category: "Breakfast", calories: 300, prepTime: 15, image: nil)
        let sampleMealPlan = MealPlan(mealType: "Breakfast", day: "Monday", recipe: sampleRecipe)
        mealPlans.append(sampleMealPlan)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mealPlans.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "mealPlanCell", for: indexPath)
        
        let mealPlan = mealPlans[indexPath.row]
        cell.textLabel?.text = "\(mealPlan.recipe.name) - \(mealPlan.recipe.calories) Cal"
        cell.detailTextLabel?.text = "\(mealPlan.mealType) - \(mealPlan.day)"
        
        if let image = mealPlan.recipe.image {
            cell.imageView?.image = image
        }
        
        return cell
    }
    
    
    @IBAction func addMealPlanTapped(_ sender: Any) {
//        performSegue(withIdentifier: "showAddRecipe", sender: self)
    }
}

